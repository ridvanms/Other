package lect13;


import java.util.function.Function;

//@FunctionalInterface
//public interface Function<T, R> {
//	//...
//	R apply(T argument);
//}

		

public class FunctionDemo {

	public static void main(String[] args) {
		Function<Integer,Double> calcArea= 
				r->Math.PI*r*r;
	    Double someArea= calcArea.apply(3);
	    
				
	}

}
