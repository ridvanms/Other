package lect13;

public class Student implements Comparable<Student>{

	private String name="Иван";
	private String specialty="КСТ";
	private double grade=3.8;
	public Student(String name, String specialty, double grade) {
		this.name = name;
		this.specialty = specialty;
		this.grade = grade;
	}
	public Student() {
		
	}
	@Override
	public String toString() {
		return  String.format("%-10s %-5s %4.2f", name, specialty, grade);
	}
	public String getName() {
		return name;
	}
	public Student setName(String name) {
		this.name = name;
		return this;
	}
	public String getSpecialty() {
		return specialty;
	}
	public Student setSpecialty(String specialty) {
		this.specialty = specialty;
		return this;
	}
	public double getGrade() {
		return grade;
	}
	public Student setGrade(double grade) {
		this.grade = grade;
		return this;
	}
	@Override
	public int compareTo(Student o) {
				return name.compareTo(o.name);
	}

}