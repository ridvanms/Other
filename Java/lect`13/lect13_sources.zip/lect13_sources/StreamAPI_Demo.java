package lect13;

import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPI_Demo {

	public static void main(String[] args) {
		// Източник - списък от примитивен тип данни
		List<Integer> nums = List.of(4, 1, 8, 2, 5);

		// Филтриране
		// Stream<T> filter(Predicate<? super T> predicate)
		Stream<Integer> odds = nums.stream().filter(x->x%2==1);
        System.out.println("Нечетни:");
        odds.forEach(System.out::println);
        
        List<Integer> evens= nums.stream()
        		.filter(x->x%2==0).collect(Collectors.toList());
        System.out.println("Четни");
        System.out.println(evens);
        
		// Прилагане на функция за преобразуване
		// <R> Stream<R> map(Function<? super T,? extends R> mapper)
		Stream<Double> sqRoots=nums.stream().map(x->Math.sqrt(x));
       System.out.println("Квадратни корени");
       // sqRoots.forEach(System.out::println);
        sqRoots.forEach(x->System.out.println(Math.round(x*100)/100.0));
        
        
		// Получаване на натрупан резултат
		// Optional<T> reduce(BinaryOperator<T> accumulator)
		Optional<Integer> sum= nums.stream().reduce((x,y)->x+y);
        System.out.println("Suma:"+sum.get());
        System.out.println("Suma:"+sum.orElse(null));
        
        Integer mult=nums.stream()
        		       .reduce((x,y)->x*y).orElse(null);
        System.out.println("mult="+mult);
        
		// Получаване на минимум (максимум)
		// Optional<T> min(Comparator<? super T> comparator)
		Integer minValue=nums.stream()
				         .min(Integer::compare).orElse(null);
		System.out.println("min="+minValue);

		// Сортиране
		// Stream<T> sorted()
		// Stream<T> sorted(Comparator<? super T> comparator)
		
      System.out.println("Sorted default");
      List<Integer> acs=nums.stream().sorted()
    		  .collect(Collectors.toList());
      System.out.println(acs);
      System.out.println("original list:"+nums);
		

//		// Източник - списък от обекти
//		List<Student> students = List.of(new Student(), new Student("Лора", "СИ", 4.3), new Student("Асен", "КСТ", 5.6),
//				new Student("Диана", "СИ", 4.8), new Student("Петър", "СИ", 5.2));

		// Филтриране по специалност
		
	}

}