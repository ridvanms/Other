package lect13;


import java.util.List;
import java.util.function.Consumer;


//@FunctionalInterface
// public interface Consumer<T> {
//   ....
//    void accept(T t);
//}
//1. Създаване на клас, който реализира интерфейса
class Cons implements Consumer<String>{
	@Override
	public void accept(String s) {
		System.out.println(s+" започва с "+s.charAt(0));		
	}	
}

public class ConsumerDemo {
    
	public static void main(String[] args) {
	//1. Използване на Cons
	Consumer<String> c= new Cons();	
	c.accept("Мария");
		
	
	//2. Oбект от анонимен клас, реализиращ интерфейса Consumer<T>

		List<String> names = List.of("Бургас", "Русе", "София", "Лом");
		// forEach - метод с подразбираща се реализация на интерфейса Collection
		// default void forEach(Consumer<? super T>action)
//		System.out.println("forEach - ламбда");
//		
//		System.out.println("forEach - референция към метод");
//		names.forEach(System.out::println);
		names.forEach(System.out::println);
		
	}
}