package lect13;

import java.util.function.Predicate;

//@FunctionalInterface
//public interface Predicate<T>{
//...
//boolean	test(T t);
//}

public class PredicateDemo {

	public static void main(String[] args) {
		Predicate<Integer> isOdd= x->x%2==1;
		Predicate<String> isLong= s->s.length()>6;
		
		System.out.println(isOdd.test(4));//false
		System.out.println(isLong.test("Мариета"));//
		 
	}

}