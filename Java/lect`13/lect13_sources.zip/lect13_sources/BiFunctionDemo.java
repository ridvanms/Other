package lect13;

import java.util.function.BiFunction;

//@FunctionalInterface
//public interface BiFunction<T,U,R>{
//	...
//	R apply(T t, U u);
//}

public class BiFunctionDemo {

	public static void main(String[] args) {
		BiFunction<Double, Integer, Double> f=
				(x,y)->x+1.5*y;
	    System.out.println(f.apply(2.4, 3));			
		
	}

}
