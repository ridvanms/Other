public interface ReadAndSaveable {
  void read(String filename);

  void save(String filename);
}
